#include <stdio.h>

/* Macro for checking GPU API return values */
#define gpuCheck(call)                                                                           \
do{                                                                                              \
    hipError_t gpuErr = call;                                                                   \
    if(hipSuccess != gpuErr){                                                                   \
        printf("GPU API Error - %s:%d: '%s'\n", __FILE__, __LINE__, hipGetErrorString(gpuErr)); \
        exit(1);                                                                                 \
    }                                                                                            \
}while(0)

void host_device_transfer(const char* direction){

    int loop_count = 50;

    for(int i=10; i<=27; i++){

        long int N = 1 << i;

        size_t bytes = N * sizeof(double);

        float milliseconds = 0.0;

        double *h_A;
        gpuCheck( hipHostMalloc(&h_A, bytes) );

        double *d_A;
        gpuCheck( hipMalloc(&d_A, bytes) );

        hipEvent_t start, stop;
        gpuCheck( hipEventCreate(&start) );
        gpuCheck( hipEventCreate(&stop) );

        for(int j=0; j<N; j++){
            h_A[j] = (double)rand()/(double)RAND_MAX;
        }

        /* Warm-up loop */
        if( strcmp(direction, "H2D") == 0){

            for(int iteration=0; iteration<5; iteration++){
                gpuCheck( hipMemcpy(d_A, h_A, bytes, hipMemcpyHostToDevice) );
            }

        }
        else if( strcmp(direction, "D2H") == 0){

            for(int iteration=0; iteration<5; iteration++){
                gpuCheck( hipMemcpy(d_A, h_A, bytes, hipMemcpyHostToDevice) );
            }        
        }
        else{
            printf("Error - unknown direction\n");
            exit(1);
        }

        gpuCheck( hipDeviceSynchronize() );
        gpuCheck( hipEventRecord(start, NULL) );

        /* Timed loop */
        if( strcmp(direction, "H2D") == 0){

            for(int iteration=0; iteration<loop_count; iteration++){
                gpuCheck( hipMemcpy(d_A, h_A, bytes, hipMemcpyHostToDevice) );
            }
        }
        else if( strcmp(direction, "D2H") == 0){

            for(int iteration=0; iteration<loop_count; iteration++){
                gpuCheck( hipMemcpy(d_A, h_A, bytes, hipMemcpyHostToDevice) );
            }
        }
        else{
            printf("Error - unknown direction\n");
            exit(1);
        }

        gpuCheck( hipEventRecord(stop, NULL) );
        gpuCheck( hipEventSynchronize(stop) );
        gpuCheck( hipEventElapsedTime(&milliseconds, start, stop) );

        gpuCheck( hipHostFree(h_A) );
        gpuCheck( hipFree(d_A) );

        double bandwidth = ( 1000.0 * (double)loop_count * (double)bytes ) / ( (double)milliseconds * 1000.0 * 1000.0 * 1000.0);
        double bytes_mb  = (double)bytes / (1024.0 * 1024.0);

        printf("Buffer Size (MiB): %14.9f, Time (ms): %14.9f, Bandwidth (GB/s): %14.9f\n", bytes_mb, milliseconds, bandwidth);
    }
}

/* --------------------------------------------------
Main program
-------------------------------------------------- */
int main(int argc, char *argv[])
{
    printf("----- H2D -----\n");
    host_device_transfer("H2D");

    printf("----- D2H -----\n");
    host_device_transfer("D2H");

    printf("\n__SUCCESS__\n");

    return 0;
}
